#Modal popup with Cookies

A simple modal popup window that uses the [jquery cookies plugin](https://github.com/carhartl/jquery-cookie) to give control over how often it appears.

[view a demo here](http://bfcdevelopment.github.io/Popup-Window/)